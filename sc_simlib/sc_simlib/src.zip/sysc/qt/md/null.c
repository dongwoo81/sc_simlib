/*
 * QuickThreads -- Threads-building toolkit.
 * Copyright (c) 1993 by David Keppel
 *
 * Permission to use, copy, modify and distribute this software and
 * its documentation for any purpose and without fee is hereby
 * granted, provided that the above copyright notice and this notice
 * appear in all copies.  This software is provided as a
 * proof-of-concept and for demonstration purposes; there is no
 * representation about the suitability of this software for any
 * purpose.
 */

char const qtmd_rcsid[] = "$Header: /Users/acg/CVSROOT/systemc/src/sysc/qt/md/null.c,v 1.1.1.1 2003/10/01 21:50:44 acg Exp $";
